
 const { SocketServer } = require('./src/services/server');
 const express = require("express");
 const http = require("http");
 app = express();
 server = http.createServer(app);

class App {
    constructor() {
        this.socketServer = new SocketServer(server);
        this.socketServer.start(server);
    }

    static bootstrap() {
        return new App();
    }
}

exports.App = App;
