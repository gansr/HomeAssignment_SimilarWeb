const Youtube = require('youtube-node');
const util = require('util');
const moment = require('moment');

let YoutubeService = class YoutubeService {
  constructor() {
      this.key = 'AIzaSyBaB1tPAVUYIopx2rnJcWfJTXiI1G4GAoo';
      this.init();
  };

  init() {
    this.youtube = new Youtube();
    this.youtube.setKey(this.key);
    this.getById = util.promisify(this.youtube.getById);
  }

  async getVideById(id) {
    let videoDetails = await this.getById(id);
    if (videoDetails.items.length === 0) {
      return;
    }

    const vid = {
      id: id,
      title: videoDetails.items[0].snippet.title,
      duration: moment.utc(moment.duration(videoDetails.items[0].contentDetails.duration).asMilliseconds()).format('HH:mm:ss')
    };
      return vid;
  }
}

exports.YoutubeService = YoutubeService;