
const serverPort = 3001;
const WebSocket = require("ws");
const { YoutubeService } = require("../modules/youtube")

let SocketServer = class SocketServer {
  constructor(server) {
      this.videoList = [];
      this.init(server);
    };

    init(server) {
      this.youtubeService = new YoutubeService();
      this.websocketServer = new WebSocket.Server({ server });

      //when a websocket connection is established
      this.websocketServer.on('connection', (webSocketClient) => {
      let res = {};
      webSocketClient.on('message', async (message) => {
        console.log(`Received message => ${message}`);
        
        try {
          let data = {};
          let msgData = JSON.parse(message);
          let action = msgData.action;
          res['action'] = action;

          if (action == 'GET') {
            data.playlist = this.videoList;
          } else {
            let videoId = msgData.videoId;
            if (action == 'ADD') {
              if (!videoId) { console.log("Nothing to add"); }
              let v = await this.youtubeService.getVideById(videoId);
              this.videoList.push(v);
              data['video'] = v;
            } else if (action == 'REMOVE') {
              if (this.videoList.length > 0) {
                this.videoList = this.videoList.filter(v => v.id !== videoId);
                data['removedVideoId'] = msgData.videoId;
              }
          }
        }

        res['data'] = data;

        } catch (e) {
          console.log(e && e.message);
        }
        webSocketClient.send(JSON.stringify(res));
      });
    });
  }

  start(server) {
    server.listen(serverPort, () => {
      console.log(`Websocket server started on port ` + serverPort);
    });
  }
}

exports.SocketServer = SocketServer;
