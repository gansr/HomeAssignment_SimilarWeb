const app = require("./app");
app.App.bootstrap();