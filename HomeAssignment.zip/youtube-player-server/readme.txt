run npm install to get node modules.
run npm start to start the app