export const ENTER = 13;
export const YOUTUBE_URL = "https://www.youtube.com/watch?v=";
export const SERVER_URL = "ws://localhost:3001";
export const NO_VIDEO_MSG = "YouTube";
export const PLACE_HOLDER_MSG = "Enter Video Id";
