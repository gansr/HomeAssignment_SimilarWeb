import { SERVER_URL } from "../config";

class SocketMsngr {
  constructor() {
    this.connection = new WebSocket(SERVER_URL);
    this.isConnectionOpen = false;
    this.msgQueue = [];

    this.initConnection();
  }

  initConnection = () => {
    this.connection.onopen = () => {
      this.isConnectionOpen = true;
      this.msgQueue.map(msg => this.sendMsg([msg]));
      this.msgQueue = [];
    };
    this.connection.onclose = () => (this.isConnectionOpen = false);
    this.connection.onerror = error => {
      console.log(`WebSocket error: ${error}`);
    };
  };

  sendMsg = msg => {
    if (this.isConnectionOpen) {
      this.connection.send([msg]);
    } else {
      this.msgQueue.push(msg);
    }
  };

  listenMsg = handler => {
    this.connection.onmessage = e => {
      handler(e.data);
    };
  };
}

export default new SocketMsngr();
