import React, { Component } from "react";
import ReactPlayer from "react-player";
import { remove } from "lodash";
import Playlist from "./components/playlist/playlist";
import SocketMsngr from "./services/socketManager";
import { YOUTUBE_URL, NO_VIDEO_MSG } from "./config";
import "./styles.css";

class App extends Component {
  state = { playlist: [] };

  componentDidMount() {
    SocketMsngr.listenMsg(msg => {
      if (msg) {
        const { playlist: curPlayList } = this.state;
        const { action, data } = JSON.parse(msg);
        let { playlist, video, removedVideoId } = {...data};

        switch (action) {
          case "GET":
            this.setState({ playlist });
            break;

          case "ADD":
            this.setState({ playlist: [...curPlayList, video] });
            break;

          case "REMOVE":
            remove(curPlayList, video => video.id === removedVideoId);
            this.setState({ playlist: curPlayList });
            break;

          default:
        }
      }
    });

    SocketMsngr.sendMsg(JSON.stringify({ action: "GET" }));
  }

  addVideo = videoId => SocketMsngr.sendMsg(JSON.stringify({ action: "ADD", videoId }));

  removeVideo = videoId => SocketMsngr.sendMsg(JSON.stringify({ action: "REMOVE", videoId }));

  videoEnd = () => this.removeVideo(this.state.playlist[0].id);

  render() {
    const { playlist } = this.state;
    const video = playlist.length && playlist[0];
    const id = video.id;
    const url = id && `${YOUTUBE_URL}${id}`;

    return (
      <div className="app-container">
        <Playlist list={playlist} onAddVideo={this.addVideo} onRemoveVideo={this.removeVideo} />
        <div className="app-player-container">
          {id ? <ReactPlayer url={url} playing onEnded={this.videoEnd} /> : <div className="app-no-video-container">{NO_VIDEO_MSG}</div>}
        </div>
      </div>
    );
  }
}

export default App;
