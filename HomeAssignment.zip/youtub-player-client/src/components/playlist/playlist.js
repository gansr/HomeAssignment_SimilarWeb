import React, { Component } from "react";
import PropTypes from "prop-types";
import { ENTER, PLACE_HOLDER_MSG, YOUTUBE_URL } from "../../config";
import VideoItem from "../videoitem/videoItem";
import "./playlist.css";

class Playlist extends Component {
  state = {
    videoIdInput: ""
  };

  handleChange = ({ target: { value } }) =>
    this.setState({ videoIdInput: value });

  handleAddVideo = () => {
    let { videoIdInput } = this.state;
    const { onAddVideo } = this.props;

    if (videoIdInput.length) {
      let videoParts = videoIdInput.split(YOUTUBE_URL);
      videoIdInput = videoParts.filter(p => p !== '')[0];
      onAddVideo(videoIdInput);
      this.setState({ videoIdInput: "" });
    }
  };

  handleKeyPress = event =>
    event.charCode === ENTER && this.handleAddVideo();

  render() {
    const { videoIdInput } = this.state;
    const { list, onRemoveVideo } = this.props;

    return (
      <div className="play-list-container">
        <div className="add-video-container">
          <input value={videoIdInput} placeholder={PLACE_HOLDER_MSG} onChange={this.handleChange} onKeyPress={this.handleKeyPress} />
          <button onClick={this.handleAddVideo}>Add</button>
        </div>
        <div className="list-container">
          {list.map(video => (<VideoItem video={video} onRemoveVideo={onRemoveVideo} />))}
        </div>
      </div>
    );
  }
}

Playlist.propTypes = {
  list: PropTypes.array,
  onAddVideo: PropTypes.func,
  onRemoveVideo: PropTypes.func
};

Playlist.defaultProps = {
  list: [],
  onAddVideo: () => {},
  onRemoveVideo: () => {}
};

export default Playlist;
