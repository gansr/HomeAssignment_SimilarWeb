import React from "react";
import PropTypes from "prop-types";
import "./videoItem.css";

const VideoItem = ({ video: { id, title, duration }, onRemoveVideo }) => (
  <div className="container">
    {title} {duration}
    <div className="close-button" onClick={() => onRemoveVideo(id)} />
  </div>
);

VideoItem.propTypes = {
  video: PropTypes.shape({
    id: PropTypes.number
  }),
  onRemoveVideo: () => {}
};

export default VideoItem;
